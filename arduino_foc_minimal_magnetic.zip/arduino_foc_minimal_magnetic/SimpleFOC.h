#ifndef SIMPLEFOC_H
#define SIMPLEFOC_H

#include "FOCutils.h"
#include "Sensor.h"
#include "Encoder.h"
#include "MagneticSensor.h"
#include "BLDCMotor.h"

#endif
