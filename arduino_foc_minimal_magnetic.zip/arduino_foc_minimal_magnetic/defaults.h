// default configuration values
// power supply voltage
#define DEF_POWER_SUPPLY 12.0
// velocity PI controller params
#define DEF_PI_VEL_P 0.5
#define DEF_PI_VEL_I 10
#define DEF_PI_VEL_U_RAMP 300
// angle P params
#define DEF_P_ANGLE_P 20
// angle velocity limit default
#define DEF_P_ANGLE_VEL_LIM 20
// index search velocity
#define DEF_INDEX_SEARCH_TARGET_VELOCITY 1

// voltage for sensor and motor zero alignemt 
#define DEF_VOLTAGE_SENSOR_ALIGN 6.0

// velocity filter time constant
#define DEF_VEL_FILTER_Tf 0.005