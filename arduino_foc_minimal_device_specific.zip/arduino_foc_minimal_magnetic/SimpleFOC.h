#ifndef SIMPLEFOC_H
#define SIMPLEFOC_H

#include "DeviceSpecific.h"
#include "FOCutils.h"
#include "Sensor.h"
#include "MagneticSensor.h"
#include "BLDCMotor.h"

#endif
