#ifndef DEVICESPECIFIC_LIB_H
#define DEVICESPECIFIC_LIB_H

#include "Arduino.h"

enum PinMode{
    IN,
    OUT,
    IN_PULLUP
};

enum InterruptMode{
    CHNAGE_VALUE,
    RISING_EDGE,
    FALLING_EDGE
};

namespace DeviceSpecific{

    // Fucntion declaring pin mode to digiatal output
    void initPinModeDigital(int pin_number, PinMode mode);
    // Funciton setting a value to the digital pin
    void digitalPinWrite(int pin_number, int value);
    // Funciton reading a value from digital pin
    int digitalPinRead(int pin_number);

    // Fucntion declaring pin mode to analog(pwm) output
    // funciton handling all the necessary pwm declarations
    void initPinModePwm(int pin_number);
    // Funciton setting a pwm value to the analog pin
    void pwmPinWrite(int pin_number, int value);

    // Fucntion implementing attaching interrupts for specific microcontroller
    void attachPinInterrupt(int pin_number, void (*handleInterrupt)(), InterruptMode mode);

    // funciton implementing delay in milliseconds
    void delay_ms(unsigned long ms);
    // funciton getting the current timestamp in microseconds
    unsigned long timestamp_us();
    
    // High PWM frequency
    void setPwmFrequency(int pin);
};

#endif