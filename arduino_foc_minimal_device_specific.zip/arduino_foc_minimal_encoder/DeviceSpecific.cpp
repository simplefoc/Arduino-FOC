#include "DeviceSpecific.h"

// Arduino UNO implementation

// Fucntion declaring pin mode to digiatal output
void DeviceSpecific::initPinModeDigital(int pin_number,PinMode mode){
  switch (mode){
  case PinMode::IN:
    pinMode(pin_number,INPUT);
    break;
  case PinMode::OUT:
    pinMode(pin_number,OUTPUT);
    break;
  case PinMode::IN_PULLUP:
    pinMode(pin_number,INPUT_PULLUP);
    break;
  }
}

// Funciton setting a value to the digital pin
void DeviceSpecific::digitalPinWrite(int pin_number, int value){
  digitalWrite(pin_number,value);
}

// Funciton reading a value from digital pin
int DeviceSpecific::digitalPinRead(int pin_number){
  return digitalRead(pin_number);
}

// Fucntion declaring pin mode to analog(pwm) output
// funciton handling all the necessary pwm declarations
void DeviceSpecific::initPinModePwm(int pin_number){
  // decare as output pin
  pinMode(pin_number,OUTPUT);
  //set high frequency pwm
  DeviceSpecific::setPwmFrequency(pin_number);
}

// Funciton setting a pwm value to the anal pin
void DeviceSpecific::pwmPinWrite(int pin_number, int value){
  analogWrite(pin_number,value);
}


// Fucntion implementing attaching interrupts for specific microcontroller
void DeviceSpecific::attachPinInterrupt(int pin_number, void (*handleInterrupt)(), InterruptMode mode){
  switch (mode){
  case InterruptMode::CHNAGE_VALUE:
    attachInterrupt(digitalPinToInterrupt(pin_number), handleInterrupt, CHANGE);
    break;
  case InterruptMode::RISING_EDGE:
    attachInterrupt(digitalPinToInterrupt(pin_number), handleInterrupt, RISING);
    break;
  case InterruptMode::FALLING_EDGE:
    attachInterrupt(digitalPinToInterrupt(pin_number), handleInterrupt, FALLING);
    break;
  }
}


// funciton implementing delay in milliseconds
void DeviceSpecific::delay_ms(unsigned long ms){
  // Arduino UNO delay function doesn't work well whn changing the TIMERS
  long t = DeviceSpecific::timestamp_us();
  while((DeviceSpecific::timestamp_us() - t)/1000 < ms){};
}


// funciton getting the current timestamp in microseconds
unsigned long DeviceSpecific::timestamp_us(){
    // return the value based on the prescaler
    if((TCCR0B & 0b00000111) == 0x01) return (micros()/32);
    else return (micros());
}

// High PWM frequency
// https://sites.google.com/site/qeewiki/books/avr-guide/timers-on-the-atmega328
void DeviceSpecific::setPwmFrequency(int pin) {
  if (pin == 5 || pin == 6 || pin == 9 || pin == 10) {
    if (pin == 5 || pin == 6) {
      // configure the pwm phase-corrected mode
      TCCR0A = ((TCCR0A & 0b11111100) | 0x01);
      // set prescaler to 1
      TCCR0B = ((TCCR0B & 0b11110000) | 0x01);
    } else {
      // set prescaler to 1
      TCCR1B = ((TCCR1B & 0b11111000) | 0x01);
    }
  }
  else if (pin == 3 || pin == 11) {
      // set prescaler to 1
    TCCR2B = ((TCCR2B & 0b11111000) | 0x01);
  }
}
